# cfboxscores
Baseball boxscore retriever using Java 8 CompletableFutures

Example used for the book _Modern Java Recipes_ by Ken Kousen, O'Reilly Media, http://shop.oreilly.com/product/0636920056669.do
