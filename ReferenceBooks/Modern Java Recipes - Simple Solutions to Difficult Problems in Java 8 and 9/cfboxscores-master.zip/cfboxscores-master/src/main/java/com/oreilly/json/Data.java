package com.oreilly.json;

public class Data {
    private Boxscore boxscore;

    public Boxscore getBoxscore() {
        return boxscore;
    }

    public void setBoxscore(Boxscore boxscore) {
        this.boxscore = boxscore;
    }
}
