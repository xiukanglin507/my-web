module com.oreilly.suppliers {
    requires gson;
    exports com.oreilly.suppliers;
}