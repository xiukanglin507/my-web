module com.kousenit.clients {
    requires java.logging;
    requires com.oreilly.suppliers;
}