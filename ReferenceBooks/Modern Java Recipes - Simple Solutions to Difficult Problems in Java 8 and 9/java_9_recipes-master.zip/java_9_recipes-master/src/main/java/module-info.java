module com.kousenit.recipes {
    // Java 10:
    // requires jdk.incubator.httpclient;

    // Java 11:
    requires java.net.http;

    requires gson;
    requires java.logging;
}