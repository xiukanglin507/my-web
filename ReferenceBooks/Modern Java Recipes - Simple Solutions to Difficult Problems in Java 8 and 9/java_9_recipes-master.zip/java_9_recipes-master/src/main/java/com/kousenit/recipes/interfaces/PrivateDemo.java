package com.kousenit.recipes.interfaces;

public class PrivateDemo implements SumNumbers {
}
