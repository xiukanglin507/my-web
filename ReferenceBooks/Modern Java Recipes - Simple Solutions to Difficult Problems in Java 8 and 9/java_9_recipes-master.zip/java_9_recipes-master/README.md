# java_9_recipes
Source code for Java 9 chapter of Modern Java Recipes

com.kousenit.recipes.http://shop.oreilly.com/product/0636920056669.do

Note: As of Dec 2018, tests have been ported to JUnit 5, modules have been added (Gson and java.logging) along with the associated Gradle modifications, and 
the code builds properly on Java 11.0.2-open.

Ken Kousen

