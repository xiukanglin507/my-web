// module-info.java
module jdojo.resource.jrt {
    requires java.desktop;
}
