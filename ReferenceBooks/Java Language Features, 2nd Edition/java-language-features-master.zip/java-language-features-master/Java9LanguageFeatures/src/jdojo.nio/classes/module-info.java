// module-info.java
module jdojo.nio {
    exports com.jdojo.nio;
}
