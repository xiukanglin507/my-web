// ForEachTest.java
package com.jdojo.streams;

public class ForEachTest {
    public static void main(String[] args) {
        
    }
}
