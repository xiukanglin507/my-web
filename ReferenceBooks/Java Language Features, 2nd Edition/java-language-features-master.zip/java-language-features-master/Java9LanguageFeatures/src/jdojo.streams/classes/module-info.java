// module-info.java
module jdojo.streams {
    exports com.jdojo.streams;
}
