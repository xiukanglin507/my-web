// module-info.java
module jdojo.annotation.test {
    exports com.jdojo.annotation.test;
    requires jdojo.annotation;
}
