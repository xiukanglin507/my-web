// module-info.java
module jdojo.resource.test {
    requires jdojo.resource;

    exports com.jdojo.resource.test;
}
