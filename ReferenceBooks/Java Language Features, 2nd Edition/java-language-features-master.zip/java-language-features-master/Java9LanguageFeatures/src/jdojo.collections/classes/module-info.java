// module-info.java
module jdojo.collections {
    exports com.jdojo.collections;
}
