// module-info.java
module jdojo.reactive.stream {
    exports com.jdojo.reactive.stream;
}
