// module-info.java
module jdojo.innerclasses {
    exports com.jdojo.innerclasses;
}
