// A.java
package com.jdojo.innerclasses;

public class A {
    public class B {
    }

    public class C extends B {
    }
    
    public class D extends A {
    }
}
