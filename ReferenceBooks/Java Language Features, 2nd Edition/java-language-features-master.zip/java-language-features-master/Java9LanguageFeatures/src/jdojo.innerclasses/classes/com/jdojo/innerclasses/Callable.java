// Callable.java
package com.jdojo.innerclasses;

public interface Callable {
    void call();
}
