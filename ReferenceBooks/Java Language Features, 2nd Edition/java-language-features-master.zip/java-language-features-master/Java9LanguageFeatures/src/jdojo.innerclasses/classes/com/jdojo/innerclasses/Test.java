// Test.java
package com.jdojo.innerclasses;

import com.jdojo.innerclasses.ComputerAccessory.Monitor;


public class Test {
    class Test2 {
                
    }
   public static void main(String[] args) {
       Test t = new Test();
       Test2 t2 = t.new Test2();
   } 
}
