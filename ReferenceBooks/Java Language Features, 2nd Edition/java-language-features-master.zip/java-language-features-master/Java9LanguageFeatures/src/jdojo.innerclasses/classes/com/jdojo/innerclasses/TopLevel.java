// TopLevel.java
package com.jdojo.innerclasses;

public class TopLevel {
    private int value = 101;

    public int getValue() {
        return value;
    }    

    public void setValue (int value) {
        this.value = value;
    }
}
