// E.java
package com.jdojo.innerclasses;

public class E extends A {
    public class F extends B {
    }
}

