// IConstants.java
package com.jdojo.reflection;

interface IConstants {
    int DAYS_IN_WEEK = 7;
}

