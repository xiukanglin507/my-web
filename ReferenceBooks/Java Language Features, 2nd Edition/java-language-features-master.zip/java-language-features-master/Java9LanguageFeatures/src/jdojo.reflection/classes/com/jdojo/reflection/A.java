// A.java
package com.jdojo.reflection;

public class A implements IConstants {
    private int aPrivate;
    public int aPublic;
    protected int aProtected;
}

