// B.java
package com.jdojo.reflection;

public class B extends A {
    private int bPrivate;
    public int bPublic;
    protected int bProtected;
}
