// module-info.java
module jdojo.resource {    
    exports com.jdojo.exported;
    
    opens com.jdojo.opened;
}

