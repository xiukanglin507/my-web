// Vodka.java
package com.jdojo.io;

public class Vodka extends Drink {
    public Vodka() {
        this.name = "Vodka";
        this.price = 1.2;
    }
}
