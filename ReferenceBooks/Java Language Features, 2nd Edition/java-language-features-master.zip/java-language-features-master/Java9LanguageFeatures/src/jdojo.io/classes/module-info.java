// module-info.java
module jdojo.io {
    exports com.jdojo.io;
}
