// Whiskey.java
package com.jdojo.io;

public class Whiskey extends Drink {
    public Whiskey() {
        this.name = "Whisky";
        this.price = 1.5;
    }
}
