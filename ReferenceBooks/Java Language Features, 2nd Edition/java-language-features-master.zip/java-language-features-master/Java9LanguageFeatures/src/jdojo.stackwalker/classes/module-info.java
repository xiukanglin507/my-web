// module-info.java
module jdojo.stackwalker {
    exports com.jdojo.stackwalker;
}
