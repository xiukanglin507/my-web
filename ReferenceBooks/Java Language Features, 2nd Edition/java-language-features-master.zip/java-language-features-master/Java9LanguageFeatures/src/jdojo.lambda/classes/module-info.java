// module-info.java
module jdojo.lambda {
    exports com.jdojo.lambda;
}
