// module-info.java
module jdojo.archives {
    exports com.jdojo.archives;
}
