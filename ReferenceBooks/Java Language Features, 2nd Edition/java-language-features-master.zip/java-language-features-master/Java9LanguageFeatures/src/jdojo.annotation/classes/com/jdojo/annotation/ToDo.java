// ToDo.java
package com.jdojo.annotation;

public @interface ToDo {
    String[] items();
}
