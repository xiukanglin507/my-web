// module-info.java
module jdojo.annotation {
    exports com.jdojo.annotation;
    
    requires java.compiler;
}
