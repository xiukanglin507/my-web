// Name.java
package com.jdojo.annotation;

public @interface Name {
    String first();
    String last();
}
