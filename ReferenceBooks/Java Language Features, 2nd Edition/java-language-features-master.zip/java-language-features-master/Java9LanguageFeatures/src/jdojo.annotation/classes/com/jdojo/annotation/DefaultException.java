// DefaultException.java
package com.jdojo.annotation;

public class DefaultException extends java.lang.Throwable {
    public DefaultException() {
    }

    public DefaultException(String msg) {
        super(msg);
    }
}
