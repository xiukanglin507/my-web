// module-info.java
module jdojo.intruder {
    // No module statements
}
