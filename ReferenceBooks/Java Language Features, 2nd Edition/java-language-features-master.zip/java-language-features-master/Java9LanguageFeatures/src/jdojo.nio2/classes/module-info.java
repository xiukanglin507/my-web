// module-info.java
module jdojo.nio2 {
    exports com.jdojo.nio2;
}
