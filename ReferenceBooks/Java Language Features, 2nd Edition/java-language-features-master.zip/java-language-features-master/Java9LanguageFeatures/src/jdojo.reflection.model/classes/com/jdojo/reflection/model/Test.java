// Test.java
package com.jdojo.reflection.model;

public class Test {
    public static void main(String[] args) {
        
    }
}
