// module-info.java
module jdojo.module.api {
    requires jdojo.prime;
    requires jdojo.intro;
    requires java.sql;
    exports com.jdojo.module.api;
}
