// module-info.java
module jdojo.module.api.test {
    requires jdojo.prime;
    requires jdojo.module.api;
}
