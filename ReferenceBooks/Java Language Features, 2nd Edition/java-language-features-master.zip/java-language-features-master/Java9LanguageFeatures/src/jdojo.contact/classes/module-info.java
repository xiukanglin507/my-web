// module-info.java
module jdojo.contact {
    exports com.jdojo.contact;
}
