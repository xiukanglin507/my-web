// module-info.java
module jdojo.threads {
    exports com.jdojo.threads;
}
