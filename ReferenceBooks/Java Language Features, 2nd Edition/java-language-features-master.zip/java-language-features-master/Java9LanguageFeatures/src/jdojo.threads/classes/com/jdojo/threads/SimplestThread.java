// SimplestThread.java
package com.jdojo.threads;

public class SimplestThread {
    public static void main(String[] args) {
        // Creates a thread object  
        Thread simplestThread = new Thread();

        // Starts the thread  
        simplestThread.start();
    }
}
