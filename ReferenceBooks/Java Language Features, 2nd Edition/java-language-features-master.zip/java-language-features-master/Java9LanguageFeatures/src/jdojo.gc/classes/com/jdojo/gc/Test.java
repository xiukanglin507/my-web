// Test.java
package com.jdojo.gc;

import java.lang.ref.Reference;
import java.util.Arrays;

public class Test {
    
    public static void main(String[] args) throws InterruptedException {        
    
    }
    
    
}
