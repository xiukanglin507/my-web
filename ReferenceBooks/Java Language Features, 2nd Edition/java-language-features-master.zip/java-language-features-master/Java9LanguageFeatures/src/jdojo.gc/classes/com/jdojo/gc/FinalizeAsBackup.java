// FinalizeAsBackup.java
package com.jdojo.gc;

public class FinalizeAsBackup {
    public static void main(String[] args) {
        
    }
}
