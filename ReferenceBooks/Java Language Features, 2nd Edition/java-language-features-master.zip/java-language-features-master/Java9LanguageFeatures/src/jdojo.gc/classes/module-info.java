// module-info.java
module jdojo.gc {
    exports com.jdojo.gc;
}
