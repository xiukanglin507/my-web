// module-info.java
module jdojo.prime.client {
    requires jdojo.prime;
}
