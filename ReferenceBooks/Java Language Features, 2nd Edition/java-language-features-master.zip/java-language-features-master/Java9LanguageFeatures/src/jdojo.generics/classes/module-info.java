// module-info.java
module jdojo.generics {
    exports com.jdojo.generics;
}
