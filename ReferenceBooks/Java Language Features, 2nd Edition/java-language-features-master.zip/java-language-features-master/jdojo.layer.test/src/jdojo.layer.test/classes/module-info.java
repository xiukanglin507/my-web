// module-info.java
module jdojo.layer.test {
    // This module reads version 1.0 of the com.jdojo.layer module
    requires jdojo.layer;
}
