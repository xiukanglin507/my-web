// module-info.com version 2.0
module jdojo.layer {
    exports com.jdojo.layer;
}
