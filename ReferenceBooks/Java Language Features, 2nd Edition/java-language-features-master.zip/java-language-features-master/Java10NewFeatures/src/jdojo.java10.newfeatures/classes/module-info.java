// module-info.java
module jdojo.java10.newfeatures {
    exports com.jdojo.java10.newfeatures;
}
