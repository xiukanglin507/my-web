// CDSTest.java
package com.jdojo.java10.newfeatures;

public class CDSTest {
    public static void main(String[] args) {
        System.out.println("Hello CDS and AppCDS");
    }
}
