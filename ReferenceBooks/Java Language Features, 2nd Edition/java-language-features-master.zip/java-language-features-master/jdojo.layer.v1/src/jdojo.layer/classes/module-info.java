// module-info.com version 1.0
module jdojo.layer {
    exports com.jdojo.layer;
}
