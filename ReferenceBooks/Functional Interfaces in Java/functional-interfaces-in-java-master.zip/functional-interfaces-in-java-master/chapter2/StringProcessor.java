package chapter2;
@FunctionalInterface
public interface StringProcessor 
{
       String process(String x);
}
