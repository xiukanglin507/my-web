package chapter1;
public interface I1
{
    void method1();
    String method2(String x);
}
