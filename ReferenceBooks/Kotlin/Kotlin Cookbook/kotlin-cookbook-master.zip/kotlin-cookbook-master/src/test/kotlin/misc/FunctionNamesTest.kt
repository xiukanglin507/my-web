package misc

import org.junit.jupiter.api.Test

class FunctionNamesTest {
    @Test
    fun `backtics make for readable test names`() {
        // ...
    }

    @Test
    fun underscores_are_fine_here_too() {
        // ...
    }
}