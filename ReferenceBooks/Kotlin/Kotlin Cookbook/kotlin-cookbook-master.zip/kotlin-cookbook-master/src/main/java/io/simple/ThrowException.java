package io.simple;

public class ThrowException {
    public static double divide(int a, int b) {
        return a / b;
    }
}
