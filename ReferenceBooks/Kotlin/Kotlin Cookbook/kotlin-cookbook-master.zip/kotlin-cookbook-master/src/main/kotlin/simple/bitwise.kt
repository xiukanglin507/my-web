package simple

fun main() {

}