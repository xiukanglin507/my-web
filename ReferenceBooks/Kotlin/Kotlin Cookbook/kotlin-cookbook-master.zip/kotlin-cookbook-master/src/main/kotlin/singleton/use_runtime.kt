package singleton

fun main() {
    val processors = Runtime.getRuntime().availableProcessors()
    println(processors)
}