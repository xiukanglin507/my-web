package misc

fun main() {
    TODO(reason = "none, really")
}

fun completeThis() {
    TODO()
}