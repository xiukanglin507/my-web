package simple

fun main(args: Array<String>) {
    println(add(1, 1))
}