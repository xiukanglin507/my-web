package misc

fun main() {
    repeat(5) {
        println("Counting: $it")
    }
}