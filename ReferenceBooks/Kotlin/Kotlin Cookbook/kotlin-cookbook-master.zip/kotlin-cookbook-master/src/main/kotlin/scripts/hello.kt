package scripts

fun main() {
    println("Hello, World!")
}