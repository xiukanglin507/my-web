fun main(args: Array<String>) {
    println("Pow!")
}